void init_Board(char* board);
void print_Board(char* board);
