void init_SNES();
int* read_SNES();
