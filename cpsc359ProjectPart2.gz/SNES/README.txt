SNES CONTROLLER

This program is a driver for the SNES controller as per the specs for CPSC 359. This program will be used to control the frogger game in the future

To set up the files in this way:

SNES folder (makefile source folder (main.c initGPIO.c initGPIO.h) build folder (main.o initGPIO.o))

To compile type 'make' into the terminal. Then run ./myProg in the terminal.
